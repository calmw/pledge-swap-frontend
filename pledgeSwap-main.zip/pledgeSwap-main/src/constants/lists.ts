export const DEFAULT_TOKEN_LIST_URL = 'https://dev-v2-backend.pledger.finance/api/v21/token?chainId=97'

export const DEFAULT_LIST_OF_LISTS: string[] = [
  "https://dev-v2-backend.pledger.finance/api/v21/token?chainId=97",
"https://dev-v2-backend.pledger.finance/api/v21/token?chainId=56"
]
