import { MenuEntry } from '@pancakeswap-libs/uikit'

const config: MenuEntry[] = [

]

export default config
